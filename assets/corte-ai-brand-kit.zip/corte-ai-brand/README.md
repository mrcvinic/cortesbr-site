# Identidade Corte AI

Criada em 7 de novembro de 2026 para o projeto Corte AI.

Nome: Corte AI. Assinatura: Grandes momentos. Seus cortes.
Símbolo: letra C angular com corte diagonal, sobre base grafite.
Paleta: grafite #14201D; lima #C7F86B; papel #F7F8F2.
Tipografia de interface e site: fontes do sistema (Arial/Helvetica/Segoe UI); nenhum arquivo de fonte externo necessário.

## Arquivos

- icon-master.png: original raster gerado, 1254 × 1254, cantos transparentes.
- logo-horizontal.png: composição original com nome, 2172 × 724, transparente.
- icon-N.png: tamanhos 16, 32, 48, 64, 128, 256, 512 e 1024.
- corte-ai.ico: Windows, tamanhos 16, 24, 32, 48, 64, 128 e 256.

Use icon-512.png no portal TikTok; confira o resultado da prévia. Use o ICO no aplicativo e instalador Windows. Logo horizontal sobre fundo claro; em fundo escuro use símbolo e nome em texto claro. Preserve proporções. Mantenha espaço livre equivalente a pelo menos 1/4 da altura do símbolo. Não distorça, acrescente contornos ou use sombras adicionais. Para dimensões muito pequenas, confira a legibilidade do C.

## Origem e manutenção

Arte original gerada para este projeto com a ferramenta imagegen da OpenAI, sem uso de imagens ou logos de concorrentes. O segundo arquivo foi gerado com o primeiro como referência. As versões menores foram redimensionadas a partir do master; o ICO reúne as resoluções Windows. Não são arquivos vetoriais. Os originais permanecem versionados, permitindo novas exportações. Não há declaração de registro de marca ou exclusividade jurídica.

O repositório do aplicativo é a fonte principal de assets/brand e site/. O site público espelha site/ no repositório cortesbr-site para manter os endereços de Termos e Privacidade já cadastrados.
